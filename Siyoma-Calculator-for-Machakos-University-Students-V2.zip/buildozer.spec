[app]

# (str) Title of your application
title = SIYOMA CALCULATOR FOR MACHAKOS UNIVERSITY STUDENTS

# (str) Package name
package.name = siyomacalculatormachakosstudents

# (str) Package domain
package.domain = com.siyomacodingprograms

# (str) Source code directory
source.dir = .

# (str) Application version
version = 2.0.0

# (str) Supported source extensions
source.include_exts = py,png,jpg,jpeg,kv,atlas

# (str) Requirements
requirements = python3,kivy

# (str) Orientation
orientation = portrait

# (bool) Fullscreen
fullscreen = 0

# (str) Android architectures
android.archs = arm64-v8a,armeabi-v7a

# (int) Android minimum API
android.minapi = 21

# (int) Android target API
android.api = 35

# (str) Android NDK version
android.ndk = 28c

# (bool) Android backup
android.allow_backup = True

# (str) Android permissions
android.permissions =

# (str) Presplash
# presplash.filename = %(source.dir)s/presplash.png

# (str) Icon
# icon.filename = %(source.dir)s/icon.png

# (str) Python-for-Android bootstrap
p4a.bootstrap = sdl2

# (bool) Warn if running as root
warn_on_root = 0


[buildozer]

# (str) Log level
log_level = 2

# (bool) Warn on root
warn_on_root = 0
