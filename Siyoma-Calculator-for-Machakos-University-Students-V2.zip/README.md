# SIYOMA CALCULATOR FOR MACHAKOS UNIVERSITY STUDENTS — V2

Copyright © 2026 SiyomaCodingPrograms

## Project
A Python/Kivy scientific calculator prepared for Android APK packaging.

## Main features
- Basic arithmetic
- Powers and roots
- Factorial
- nPr and nCr
- Trigonometric and inverse trigonometric functions
- Hyperbolic and inverse hyperbolic functions
- log and ln
- π and e
- Percentage
- Absolute value
- Reciprocal
- DEG/RAD mode
- M+, M-, MR, MC
- Ans
- Random numbers
- Calculation history
- Error handling

## Android build
The repository includes:
- `main.py`
- `buildozer.spec`
- `.github/workflows/build.yml`

The GitHub Actions workflow is intended to build a debug APK and upload it as an artifact.

## Important
V1 is a separate project and is not modified by this V2 project.
