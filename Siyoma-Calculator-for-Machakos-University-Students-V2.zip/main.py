# ============================================================
# SIYOMA CALCULATOR FOR MACHAKOS UNIVERSITY STUDENTS V2
# ============================================================
# Copyright © 2026 SiyomaCodingPrograms
# ============================================================
#
# Scientific • Engineering • Statistics Calculator
#
# Features:
# Basic arithmetic, powers, roots, factorial, nPr, nCr,
# sin/cos/tan, inverse trig, hyperbolic functions,
# logarithms, π, e, percentage, absolute value, reciprocal,
# DEG/RAD, memory, Ans, random numbers, history, error handling.
# ============================================================

import math
import random

from kivy.app import App
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView


class CalculatorEngine:

    def __init__(self):
        self.memory = 0
        self.answer = 0
        self.degrees = True
        self.history = []

    def nPr(self, n, r):
        n = int(n)
        r = int(r)
        if n < 0 or r < 0 or r > n:
            raise ValueError
        return math.factorial(n) // math.factorial(n - r)

    def nCr(self, n, r):
        n = int(n)
        r = int(r)
        if n < 0 or r < 0 or r > n:
            raise ValueError
        return math.factorial(n) // (
            math.factorial(r) * math.factorial(n - r)
        )

    def sin(self, x):
        if self.degrees:
            x = math.radians(x)
        return math.sin(x)

    def cos(self, x):
        if self.degrees:
            x = math.radians(x)
        return math.cos(x)

    def tan(self, x):
        if self.degrees:
            x = math.radians(x)
        return math.tan(x)

    def asin(self, x):
        result = math.asin(x)
        return math.degrees(result) if self.degrees else result

    def acos(self, x):
        result = math.acos(x)
        return math.degrees(result) if self.degrees else result

    def atan(self, x):
        result = math.atan(x)
        return math.degrees(result) if self.degrees else result

    def sinh(self, x):
        return math.sinh(x)

    def cosh(self, x):
        return math.cosh(x)

    def tanh(self, x):
        return math.tanh(x)

    def asinh(self, x):
        return math.asinh(x)

    def acosh(self, x):
        return math.acosh(x)

    def atanh(self, x):
        return math.atanh(x)

    def root(self, x, n):
        if n == 0:
            raise ValueError
        if x < 0 and n % 2 == 0:
            raise ValueError
        if x < 0:
            return -((-x) ** (1 / n))
        return x ** (1 / n)

    def calculate(self, expression):
        try:
            expression = expression.replace("×", "*")
            expression = expression.replace("÷", "/")
            expression = expression.replace("^", "**")
            expression = expression.replace("π", "pi")

            allowed = {
                "pi": math.pi,
                "e": math.e,
                "sqrt": math.sqrt,
                "abs": abs,
                "log": math.log10,
                "ln": math.log,
                "factorial": math.factorial,
                "nPr": self.nPr,
                "nCr": self.nCr,
                "sin": self.sin,
                "cos": self.cos,
                "tan": self.tan,
                "asin": self.asin,
                "acos": self.acos,
                "atan": self.atan,
                "sinh": self.sinh,
                "cosh": self.cosh,
                "tanh": self.tanh,
                "asinh": self.asinh,
                "acosh": self.acosh,
                "atanh": self.atanh,
                "root": self.root,
                "pow": pow,
            }

            result = eval(
                expression,
                {"__builtins__": {}},
                allowed,
            )

            self.answer = result
            self.history.append(f"{expression} = {result}")
            return result

        except ZeroDivisionError:
            return "ERROR: Division by zero"
        except ValueError:
            return "ERROR: Invalid value"
        except OverflowError:
            return "ERROR: Number too large"
        except Exception:
            return "ERROR"


class SuperiorCalculator(BoxLayout):

    def __init__(self, **kwargs):
        super().__init__(
            orientation="vertical",
            spacing=dp(4),
            padding=dp(7),
            **kwargs
        )

        self.engine = CalculatorEngine()

        title = Label(
            text="[b]SIYOMA CALCULATOR[/b]",
            markup=True,
            font_size=dp(23),
            size_hint_y=None,
            height=dp(40),
        )
        self.add_widget(title)

        subtitle = Label(
            text="FOR MACHAKOS UNIVERSITY STUDENTS",
            font_size=dp(11),
            size_hint_y=None,
            height=dp(23),
        )
        self.add_widget(subtitle)

        self.display = TextInput(
            multiline=False,
            font_size=dp(24),
            halign="right",
            size_hint_y=None,
            height=dp(65),
        )
        self.add_widget(self.display)

        info = BoxLayout(size_hint_y=None, height=dp(35))

        self.mode_button = Button(text="DEG")
        self.mode_button.bind(on_press=self.toggle_mode)
        info.add_widget(self.mode_button)

        self.answer_label = Label(text="Ans: 0")
        info.add_widget(self.answer_label)

        self.add_widget(info)

        grid = GridLayout(cols=5, spacing=dp(3))

        buttons = [
            "MC", "MR", "M+", "M-", "AC",
            "sin", "cos", "tan", "asin", "acos",
            "atan", "sinh", "cosh", "tanh", "√",
            "nPr", "nCr", "n!", "x²", "xʸ",
            "root", "1/x", "|x|", "%", "log",
            "ln", "π", "e", "(", ")",
            "7", "8", "9", "÷", "⌫",
            "4", "5", "6", "×", "^",
            "1", "2", "3", "-", "RAND",
            "0", ".", "=", "+", "Ans",
            "asinh", "acosh", "atanh", "HISTORY", "C",
        ]

        for text in buttons:
            button = Button(text=text, font_size=dp(14))
            button.bind(on_press=self.button_pressed)
            grid.add_widget(button)

        self.add_widget(grid)

        history_title = Label(
            text="[b]CALCULATION HISTORY[/b]",
            markup=True,
            size_hint_y=None,
            height=dp(25),
        )
        self.add_widget(history_title)

        scroll = ScrollView(size_hint_y=None, height=dp(65))

        self.history_label = Label(
            text="",
            size_hint_y=None,
            halign="left",
            valign="top",
        )
        self.history_label.bind(
            texture_size=self.history_label.setter("size")
        )

        scroll.add_widget(self.history_label)
        self.add_widget(scroll)

        copyright_label = Label(
            text="© 2026 SiyomaCodingPrograms",
            font_size=dp(10),
            size_hint_y=None,
            height=dp(22),
        )
        self.add_widget(copyright_label)

    def button_pressed(self, button):
        value = button.text

        if value in ("AC", "C"):
            self.display.text = ""
            return

        if value == "⌫":
            self.display.text = self.display.text[:-1]
            return

        if value == "MC":
            self.engine.memory = 0
            return

        if value == "MR":
            self.display.text += str(self.engine.memory)
            return

        if value == "M+":
            result = self.engine.calculate(self.display.text)
            if isinstance(result, (int, float)):
                self.engine.memory += result
            return

        if value == "M-":
            result = self.engine.calculate(self.display.text)
            if isinstance(result, (int, float)):
                self.engine.memory -= result
            return

        if value == "Ans":
            self.display.text += str(self.engine.answer)
            return

        if value == "RAND":
            self.display.text += str(random.random())
            return

        if value == "HISTORY":
            self.update_history()
            return

        if value == "n!":
            self.display.text += "factorial("
            return

        if value == "√":
            self.display.text += "sqrt("
            return

        if value == "|x|":
            self.display.text += "abs("
            return

        if value == "1/x":
            expression = self.display.text
            self.display.text = f"1/({expression})"
            return

        if value == "x²":
            expression = self.display.text
            self.display.text = f"({expression})**2"
            return

        if value == "xʸ":
            self.display.text += "^"
            return

        if value == "root":
            self.display.text += "root("
            return

        if value == "%":
            self.display.text += "/100"
            return

        functions = [
            "sin", "cos", "tan",
            "asin", "acos", "atan",
            "sinh", "cosh", "tanh",
            "asinh", "acosh", "atanh",
            "log", "ln",
        ]

        if value in functions:
            self.display.text += value + "("
            return

        if value == "nPr":
            self.display.text += "nPr("
            return

        if value == "nCr":
            self.display.text += "nCr("
            return

        if value == "=":
            expression = self.display.text
            result = self.engine.calculate(expression)

            if isinstance(result, float):
                if result.is_integer():
                    result = int(result)
                else:
                    result = round(result, 10)

            self.display.text = str(result)
            self.answer_label.text = f"Ans: {result}"
            self.update_history()
            return

        self.display.text += value

    def toggle_mode(self, instance):
        self.engine.degrees = not self.engine.degrees
        self.mode_button.text = "DEG" if self.engine.degrees else "RAD"

    def update_history(self):
        self.history_label.text = "\n".join(
            self.engine.history[-10:]
        )


class SuperiorCalculatorApp(App):

    def build(self):
        Window.clearcolor = (0.04, 0.04, 0.04, 1)
        return SuperiorCalculator()


if __name__ == "__main__":
    SuperiorCalculatorApp().run()
